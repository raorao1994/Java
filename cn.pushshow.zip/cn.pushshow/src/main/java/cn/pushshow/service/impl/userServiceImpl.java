package cn.pushshow.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.pushshow.mapper.UserMapper;
import cn.pushshow.po.User;
import cn.pushshow.po.UserExample;
import cn.pushshow.service.userService;

@Transactional
@Service
public class userServiceImpl implements userService {
	
	@Autowired
	private UserMapper dao;

	@Override
	public int countByExample(UserExample example) {
		// TODO 自动生成的方法存根
		return dao.countByExample(example);
	}

	@Override
	public int deleteByExample(UserExample example) {
		// TODO 自动生成的方法存根
		return dao.deleteByExample(example);
	}

	@Override
	public int deleteByPrimaryKey(Integer id) {
		// TODO 自动生成的方法存根
		return dao.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(User record) {
		// TODO 自动生成的方法存根
		int result=dao.insert(record);
		return result;
	}

	@Override
	public int insertSelective(User record) {
		// TODO 自动生成的方法存根
		return dao.insertSelective(record);
	}

	@Override
	public List<User> selectByExample(UserExample example) {
		// TODO 自动生成的方法存根
		return dao.selectByExample(example);
	}

	@Override
	public User selectByPrimaryKey(Integer id) {
		// TODO 自动生成的方法存根
		return dao.selectByPrimaryKey(id);
	}

	@Override
	public int updateByExampleSelective(User record, UserExample example) {
		// TODO 自动生成的方法存根
		return dao.updateByExampleSelective(record, example);
	}

	@Override
	public int updateByExample(User record, UserExample example) {
		// TODO 自动生成的方法存根
		return dao.updateByExample(record, example);
	}

	@Override
	public int updateByPrimaryKeySelective(User record) {
		// TODO 自动生成的方法存根
		return dao.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(User record) {
		// TODO 自动生成的方法存根
		return dao.updateByPrimaryKey(record);
	}

}
