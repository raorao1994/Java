package cn.pushshow.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.pushshow.model.ResultModel;
import cn.pushshow.po.User;
import cn.pushshow.service.userService;

@RestController
@RequestMapping("/user")
public class userController {
	
	@Autowired
	private userService service;
	
	@RequestMapping("/insert")
	public ResultModel insert(){
		
		ResultModel result=new ResultModel();
		
		User record=new User();
		record.setAccount("cxw");
		record.setPassword("123");
		Date d=new Date();
		record.setBirthday(d);
		record.setPhone(123456798);
		
		service.insert(record);
		
		result.setState(200);
		result.setData(record);
		result.setMessage("success");
		
		return result;
	}
	
	@RequestMapping("/selectall")
	public ResultModel SelectAll()
	{
		List<User> list=service.selectByExample(null);
		ResultModel result=new ResultModel();
		result.setState(200);
		result.setData(list);
		result.setMessage("success");
		
		return result;
	}
}
