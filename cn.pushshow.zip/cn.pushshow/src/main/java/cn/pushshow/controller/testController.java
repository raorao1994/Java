package cn.pushshow.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.pushshow.model.ResultModel;
import cn.pushshow.po.User;
import cn.pushshow.service.userService;

@RestController
@RequestMapping("/test")
public class testController {
	@Autowired
	private userService service;
	
	@RequestMapping("/index")
	public String index(){
		return "测试controller-index";
	}
	
	
	@RequestMapping("/erro")
	public String erro(){
		int i=1/0;
		return "测试controller-index";
	}
	
	@RequestMapping("/erroinsert")
	public ResultModel insert(){
		
		ResultModel result=new ResultModel();
		
		User record=new User();
		record.setAccount("cm");
		record.setPassword("456");
		Date d=new Date();
		record.setBirthday(d);
		record.setPhone(456);
		service.insert(record);
		
		
		
		result.setState(200);
		result.setData(record);
		result.setMessage("success");
		
		return result;
	}
	
}
