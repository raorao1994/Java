package cn.pushshow.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.pushshow.model.ResultModel;

/*
 * 全局异常处理应该放在controller包中
 * */
@ControllerAdvice 
public class GlobalException {
	
	@ExceptionHandler(Exception.class)
	@ResponseBody
	public ResultModel exceptionHandler(Exception ex){
		ResultModel result=new ResultModel();
		result.setState(500);
		result.setMessage(ex.getMessage());
		System.out.println("报错啦！！！");
		System.out.println(ex);
		return result;
	}
}
