package cn.pushshow.model;

public class ResultModel {
	//状态码
	private int state;
	//返回数据
	private Object data;
	//信息
	private String message;
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
